Contact
=======

For any questions or suggestions please contact us at: chipsec@intel.com

We also have the `issue tracker <https://github.com/chipsec/chipsec/issues>`_ in our GitHub repo. If you'd like to report a bug or make a request please open an issue.

If you'd like to make a contribution to the code please open a `pull request <https://github.com/chipsec/chipsec/pulls>`_

Mailing lists:

 * CHIPSEC users: https://groups.google.com/forum/#!forum/chipsec-users
 * CHIPSEC discussion list on 01.org: https://lists.01.org/hyperkitty/list/chipsec@lists.01.org/

Twitter:

 * For CHIPSEC release alerts: Follow `CHIPSEC Release <https://twitter.com/ChipsecR>`_
 * For general CHIPSEC info: Follow `CHIPSEC <https://twitter.com/Chipsec>`_

.. note::

    For **AMD** related questions or suggestions please contact Gabriel Kerneis at: Gabriel.Kerneis@ssi.gouv.fr
